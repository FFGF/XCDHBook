module.exports = async (ctx) => {
    ctx.state.data = {
        msg: 'hello 小程序后台233'
    }
}
